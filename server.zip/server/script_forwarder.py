from __main__ import app

import os
from multiprocessing import Pool

processes = ("../main1.py", "../main2.py","../youtubestream.py")#, "ml_sub_client.py")
@app.route('/script1/')
def script1():
    pool = Pool(processes=3)

    pool.map(run_process, processes)
    return #'This would do script1 things'

@app.route('/script2/')
def script2():
    os.system('python ../ml_sub_client.py')
    return #'This would do script2 things'

@app.route('/script3/')
def script3():
    os.system('python ../webserver.py')
    return #'This would do script3 things'



#process_dict = {"main": "main.py", "main2": "main2.py","zmqser": "zmqser.py", "ml_sub_client": "ml_sub_client.py", "webserver": "webserver.py"}, "webserver.py" youtubestream
#running_process = {}

def run_process(process):
    os.system('python {}'.format(process))

