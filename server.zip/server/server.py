#
#@app.route('/')
#def index():
#  return render_template('index.html')
#
#import my-link
#
###@app.route('/my-link/')
###def my_link():
###  print ('I got clicked!')
##
##  return 'Click.'
#
#if __name__ == '__main__':
#  app.run(debug=True)

from flask import Flask, request, abort, render_template

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

# import declared routes
import script_forwarder

if __name__ == '__main__':
    app.run(debug=True)
